# PWFusion_MCP2515
Arduino library for the Microchip MCP2515 CAN controller

# PWFusion_MAX31865
![IFB-10003 ISO](http://www.playingwithfusion.com/include/getimg.php?imgid=1240)

Microchip MCP2510 and MCP2515 CAN Controller Arduino Library provided to interface with Playing With Fusion IFB-10003 shields

Product page links with schematics and hardware details:
- IFB-10003-ANP: <a href="http://www.playingwithfusion.com/productview.php?pdid=47">Automotive DB9 pinout, No onboard power supply</a>
- IFB-10003-AWP: <a href="http://www.playingwithfusion.com/productview.php?pdid=48">Automotive DB9 pinout, Integrated power supply</a>
- IFB-10003-INP: <a href="http://www.playingwithfusion.com/productview.php?pdid=49">Industrial (Standard) DB9 pinout, No onboard power supply</a>
- IFB-10003-IWP: <a href="http://www.playingwithfusion.com/productview.php?pdid=50">Industrial (Standard), Integrated power supply</a>

Questions? Feel free to <a href="http://www.playingwithfusion.com/contactus.php">contact us!</a>
